﻿namespace $safeprojectname$.Interfaces
{
    // Інтерфейс для реалізації
    interface IRenderer
    {
        void RenderCircle(double radius);
    }
}
